from django.urls import path
from . import views
from . import consumers1

urlpatterns = [
    path("",views.index),
    path("sahil/",consumers1.sahil)
]
